package notes;


/**
 * Write a description of class A here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class A
{
   
    public A()
    {
        // initialise instance variables
        
    }

    public void firstMethod()
    {
        System.out.println("First Method: A");
    }
    
    public void secondMethod()
    {
        System.out.println("Second Method: A");
    }
}
