package notes;


/**
 * Write a description of class C here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class C extends B
{
    public C()
    {
        // initialise instance variables
        super();
    }

    public void firstMethod()
    {
        super.firstMethod();
    }
}
