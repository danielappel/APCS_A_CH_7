package notes.homework;


/**
 * Write a description of class A here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class A
{
    void foo() {
        System.out.println("A's foo");
    }
}
