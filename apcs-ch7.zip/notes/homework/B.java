package notes.homework;


/**
 * Write a description of class B here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class B extends A
{
    public void foo() {
        System.out.println("B's foo");
    }
}
